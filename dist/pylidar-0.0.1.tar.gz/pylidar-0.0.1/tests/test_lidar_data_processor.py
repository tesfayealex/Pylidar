import os
import sys
import unittest

# sys.path.append(os.path.abspath(os.path.join('../src')))


class TestFileHandler(unittest.TestCase):

  def setUp(self):
    pass

if __name__ == '__main__':
  unittest.main()